package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

import com.devsu.hackerearth.backend.account.constants.TypeTransaction;
import com.devsu.hackerearth.backend.account.controller.AccountController;
import com.devsu.hackerearth.backend.account.controller.TransactionController;
import com.devsu.hackerearth.backend.account.exception.AccountException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.AccountService;
import com.devsu.hackerearth.backend.account.service.TransactionService;

@SpringBootTest
@ActiveProfiles("test")
public class sampleTest {

	private AccountService accountService = mock(AccountService.class);
	private AccountController accountController = new AccountController(accountService);
	private TransactionService transactionService = mock(TransactionService.class);
	private TransactionController transactionController = new TransactionController(transactionService);
	// private RestTemplate restTemplate = mock(RestTemplate.class);

	@Autowired
	private AccountController accountCont;

	@Autowired
	private TransactionController transactionCont;

	@MockBean
	private RestTemplate restTemplate;

	@Test
	void createAccountTest() {
		// Arrange
		AccountDto newAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		AccountDto createdAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		when(accountService.create(newAccount)).thenReturn(createdAccount);

		// Act
		ResponseEntity<AccountDto> response = accountController.create(newAccount);

		// Assert
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertEquals(createdAccount, response.getBody());
	}

	@Test
	void partialUpdate() {
		// Arrange
		Long id = 999L;
		PartialAccountDto obj = new PartialAccountDto();
		obj.setActive(false);
		// when(accountService.getById(11L)).thenReturn(Optional.empty());
		when(accountService.partialUpdate(id, obj)).thenThrow(new AccountException("Cuenta no existe"));
		ResponseEntity<AccountDto> response = null;
		// Act
		try {
			response = accountController.partialUpdate(id,
					obj);
		} catch (AccountException ex) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		// Assert
		assertThrows(AccountException.class, () -> accountController.partialUpdate(id, obj));
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

	}

	@Test
	void flujoCompleto() {
		// 1. Crear Cuenta
		AccountDto newAccount = new AccountDto(1L, "number", "savings", 10.0, true, 1L);
		// AccountDto createdAccount = new AccountDto(1L, "number", "savings", 10.0,
		// true, 1L);
		// when(accountService.create(newAccount)).thenReturn(createdAccount);

		// Act
		ResponseEntity<AccountDto> response = accountCont.create(newAccount);
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		// assertEquals(newAccount, response.getBody());

		// 2. Crear Movimiento de CREDITSO
		TransactionDto trxCredito = new TransactionDto(null, new Date(), TypeTransaction.CREDITO.name(), 100, 0,
				response.getBody().getId());
		ResponseEntity<TransactionDto> trxCre = transactionCont.create(trxCredito);

		assertEquals(HttpStatus.CREATED, trxCre.getStatusCode());
		// assertEquals(newAccount, response.getBody());

		// 3. Crear Movimiento de DEBITOS
		TransactionDto trxDebito = new TransactionDto(null, new Date(), TypeTransaction.DEBITO.name(), 40, 100,
				response.getBody().getId());
		ResponseEntity<TransactionDto> trxDeb = transactionCont.create(trxDebito);

		assertEquals(HttpStatus.CREATED, trxDeb.getStatusCode());
		// assertEquals(newAccount, response.getBody());

		// 4. CRear movimiendo de Debito con saldo insuficienbte
		TransactionDto trxDebito2 = new TransactionDto(null, new Date(), TypeTransaction.DEBITO.name(), 100, 0,
				response.getBody().getId());
		// ResponseEntity<TransactionDto> trxDeb2 = transactionCont.create(trxDebito2);
		AccountException ex = assertThrows(AccountException.class, () -> transactionCont.create(trxDebito2));

		// assertEquals(HttpStatus.CREATED, trxDeb2.getStatusCode());
		assertEquals("Saldo no Disponible", ex.getMessage());

		// 5. Generar Reportes
		System.out.println("===========================");
		System.out.println("========= REPORTE ======");
		System.out.println("===========================");

		ClientDto client = new ClientDto(1L, null, "Danny", null, null, 0, null, null, false);
		Date fechaInicio = new Date(System.currentTimeMillis() - (24 * 60 * 60 * 1000));
		Date fechaFin = new Date(System.currentTimeMillis() + (24 * 60 * 60 * 1000));

		when(restTemplate.getForEntity(anyString(), eq(ClientDto.class))).thenReturn(ResponseEntity.ok(client));
		ResponseEntity<List<BankStatementDto>> lstData = transactionCont.report(response.getBody().getClientId(),
				fechaInicio, fechaFin);

		System.out.println(response.getBody().getClientId());
		System.out.println(lstData.getBody());
	}
}
