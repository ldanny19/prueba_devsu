package com.devsu.hackerearth.backend.account.model.dto;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.devsu.hackerearth.backend.account.constants.CodeTransactionMessage;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TransactionDto {

	private Long id;

	@NotNull(message = CodeTransactionMessage.TRANSACTION_DATA_NOT_FOUND)
	private Date date;
	@NotBlank(message = CodeTransactionMessage.TRANSACCION_TYPE_OBLIGATORY)
	private String type;
	@NotNull(message = CodeTransactionMessage.TRANSACTION_AMOUNT_OBLIGATORY)
	private double amount;
	private double balance;
	@NotNull(message = CodeTransactionMessage.TRANSACCION_ACCOUNTID_OBLIGATORY)
	private Long accountId;
}
