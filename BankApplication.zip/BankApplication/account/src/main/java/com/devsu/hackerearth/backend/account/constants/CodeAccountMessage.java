package com.devsu.hackerearth.backend.account.constants;

public final class CodeAccountMessage {

    public static final String ACCOUNT_DATA_NOT_FOUND = "Datos de Cuentas no encontrados";
    public static final String ACCOUNT_NOT_FOUND = "Cuenta no existe";
    public static final String ACCOUNT_NUMBER_OBLIGATORY = "El numnero de cuenta es obligatorio";
    public static final String ACCOUNT_TYPE_OBLIGATORY = "El tipo de cuenta es obligatorio";
    public static final String ACCOUNT_INIT_AMOUNT_OBLIGATORY = "El valor inicial de la cuenta es obligatorio";
    public static final String ACCOUNT_INIT_AMOUNT_POSITIBE = "El valor inicial de la cuenta debe ser mayor a 0";
    public static final String ACCOUNT_CLIENTID_OBLIGATORY = "El id del Cliente dueño de la cuenta es obligatorio";
    public static final String ACCOUNT_STATUS_OBLIGATORY = "El estado del Cliente es obligatorio";


}