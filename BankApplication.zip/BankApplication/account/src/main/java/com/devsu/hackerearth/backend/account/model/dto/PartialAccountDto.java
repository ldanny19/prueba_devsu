package com.devsu.hackerearth.backend.account.model.dto;

import javax.validation.constraints.NotNull;

import com.devsu.hackerearth.backend.account.constants.CodeAccountMessage;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PartialAccountDto {

	@NotNull(message = CodeAccountMessage.ACCOUNT_STATUS_OBLIGATORY)
	private boolean isActive;
}
