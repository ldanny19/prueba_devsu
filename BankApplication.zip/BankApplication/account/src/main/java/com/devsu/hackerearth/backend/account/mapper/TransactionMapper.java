package com.devsu.hackerearth.backend.account.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;

@Component
public class TransactionMapper {

    public Transaction toEntity(TransactionDto dto) {
        if (dto == null) {
            return null;
        }
        Transaction obj = new Transaction();

        obj.setAccountId(dto.getAccountId());
        obj.setAmount(dto.getAmount());
        obj.setBalance(dto.getBalance());
        obj.setDate(dto.getDate());
        obj.setId(dto.getId());
        obj.setType(dto.getType());
        return obj;
    }

    public TransactionDto toDto(Transaction entity) {

        if (entity == null) {
            return null;
        }
        TransactionDto obj = new TransactionDto(entity.getId(), entity.getDate(), entity.getType(), entity.getAmount(),
                entity.getBalance(), entity.getAccountId());
        return obj;
    }

    public List<Transaction> toEntityList(List<TransactionDto> dtoList) {
        if (dtoList == null) {
            return null;
        }
        return dtoList.stream().map(this::toEntity).collect(Collectors.toList());
    }

    public List<TransactionDto> toDtoList(List<Transaction> entityList) {
        if (entityList == null) {
            return null;
        }
        return entityList.stream().map(this::toDto).collect(Collectors.toList());
    }

}
