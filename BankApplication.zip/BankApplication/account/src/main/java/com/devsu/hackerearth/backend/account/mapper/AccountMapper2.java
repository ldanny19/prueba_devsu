package com.devsu.hackerearth.backend.account.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;


@Mapper(componentModel = "spring")
public interface AccountMapper2 {

    Account toEntity(AccountDto dto);

    AccountDto toDto(Account entity);

    List<Account> toEntityList(List<AccountDto> dtoList);
    List<AccountDto> toDtoList(List<Account> entityList);

}
