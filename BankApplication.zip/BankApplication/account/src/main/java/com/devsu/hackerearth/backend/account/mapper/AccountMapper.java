package com.devsu.hackerearth.backend.account.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;

@Component
public class AccountMapper {

    public Account toEntity(AccountDto dto) {
        if (dto == null) {
            return null;
        }
        Account obj = new Account();
        obj.setActive(dto.isActive());
        obj.setClientId(dto.getClientId());
        obj.setId(dto.getId());
        obj.setInitialAmount(dto.getInitialAmount());
        obj.setNumber(dto.getNumber());
        obj.setType(dto.getType());
        return obj;
    }

    public AccountDto toDto(Account entity) {

        if (entity == null) {
            return null;
        }
        AccountDto obj = new AccountDto(entity.getId(), entity.getNumber(),entity.getType(),entity.getInitialAmount(), entity.isActive(),entity.getClientId());
        return obj;
    }

    public List<Account> toEntityList(List<AccountDto> dtoList) {
        if (dtoList == null) {
            return null;
        }
        return dtoList.stream().map(this::toEntity).collect(Collectors.toList());
    }

    public List<AccountDto> toDtoList(List<Account> entityList) {
        if (entityList == null) {
            return null;
        }
        return entityList.stream().map(this::toDto).collect(Collectors.toList());
    }

}
