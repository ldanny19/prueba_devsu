package com.devsu.hackerearth.backend.account.constants;

public enum TypeTransaction {
    CREDITO,
    DEBITO
}
