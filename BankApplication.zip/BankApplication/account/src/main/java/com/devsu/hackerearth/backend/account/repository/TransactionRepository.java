package com.devsu.hackerearth.backend.account.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    Optional<Transaction> findTopByAccountIdOrderByDateDesc(Long id);

    @Query("SELECT new com.devsu.hackerearth.backend.account.model.dto.BankStatementDto( t.date, '', a.number, a.type, a.initialAmount, a.isActive, t.type, t.amount, t.balance)  FROM Account a, Transaction t where t.accountId = a.id and a.clientId = :clienteID and t.date between :fechaInicio and :fechaFin ")
    List<BankStatementDto> findByAccountClientIdAndDateBetween(@Param("clienteID") Long clientID,
            @Param("fechaInicio") Date starDate, @Param("fechaFin") Date endDate);

}