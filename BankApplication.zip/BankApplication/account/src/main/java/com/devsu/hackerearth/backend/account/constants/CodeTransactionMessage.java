package com.devsu.hackerearth.backend.account.constants;

public final class CodeTransactionMessage {

    public static final String TRANSACTION_DATA_NOT_FOUND = "Datos de transacciones no encontrados";
    public static final String TRANSACTION_NOT_FOUND = "Transaccion no existe";
    public static final String TRANSACTION_DATE_OBLIGATORY = "La fecha de la transaccion es obligatorio";
    public static final String TRANSACCION_TYPE_OBLIGATORY = "El tipo de trasnaccion es obligatorio";
    public static final String TRANSACTION_AMOUNT_OBLIGATORY = "El valor de la trasnaccion es obligatorio";
    public static final String TRANSACCION_ACCOUNTID_OBLIGATORY = "La cuenta de la trasnaccion es obligatorio";
    public static final String TRANSACCION_ACCOUNDID_NOT_FOUND = "La cuenta de la trasnaccion no tiene movimientos";
    public static final String TRANSACCION_BALANCE_NOT_DISPONIBILITY = "Saldo no Disponible";
    public static final String TRANSACTION_ID_OBLIGATPORY = "El id de la transaccion debe ser obligatorio";

}