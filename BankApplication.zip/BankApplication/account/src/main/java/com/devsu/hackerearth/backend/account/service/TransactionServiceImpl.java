package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.devsu.hackerearth.backend.account.constants.CodeTransactionMessage;
import com.devsu.hackerearth.backend.account.constants.TypeTransaction;
import com.devsu.hackerearth.backend.account.exception.AccountException;
import com.devsu.hackerearth.backend.account.mapper.TransactionMapper;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final TransactionMapper transactionMapper;
    private final RestTemplate restTemplate;

    public TransactionServiceImpl(TransactionRepository transactionRepository,
            TransactionMapper transactionMapper,
            AccountRepository accountRepository, RestTemplate restTemplate) {
        this.transactionRepository = transactionRepository;
        this.transactionMapper = transactionMapper;
        this.restTemplate = restTemplate;
    }

    @Override
    public List<TransactionDto> getAll() {
        List<Transaction> listTrans = transactionRepository.findAll();
        if (listTrans == null || listTrans.isEmpty()) {
            throw new AccountException(CodeTransactionMessage.TRANSACTION_DATA_NOT_FOUND);
        }
        return transactionMapper.toDtoList(listTrans);
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        Transaction transaccion = transactionRepository.findById(id)
                .orElseThrow(() -> new AccountException(CodeTransactionMessage.TRANSACTION_NOT_FOUND));
        return transactionMapper.toDto(transaccion);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        TransactionDto trxTmp = getLastByAccountId(transactionDto.getAccountId());

        double balanceActual = trxTmp.getBalance();
        if (TypeTransaction.CREDITO.name().equals(transactionDto.getType())) {
            transactionDto.setBalance(balanceActual + transactionDto.getAmount());
        } else if (TypeTransaction.DEBITO.name().equals(transactionDto.getType())) {
            if (transactionDto.getAmount() > balanceActual) {
                throw new AccountException(CodeTransactionMessage.TRANSACCION_BALANCE_NOT_DISPONIBILITY);
            }
            transactionDto.setBalance(balanceActual - transactionDto.getAmount());
        }
        System.out.println("ID = " + trxTmp.getId());
        System.out.println("FECHA = " + trxTmp.getDate());
        System.out.println("VALOR ACTUAL = " + balanceActual);
        System.out.println("VALOR ACTUAL = " + transactionDto.getBalance());
        Transaction transaction = transactionMapper.toEntity(transactionDto);
        Transaction transSaved = transactionRepository.save(transaction);
        return transactionMapper.toDto(transSaved);
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report
        // List<Transaction> lstTrans =
        // transactionRepository.findByAccountClientIdAndDateBetween(clientId,
        // dateTransactionStart, dateTransactionEnd);

        List<BankStatementDto> lstTrans = transactionRepository.findByAccountClientIdAndDateBetween(clientId,
                dateTransactionStart, dateTransactionEnd);

        ResponseEntity<ClientDto> clientDto = restTemplate.getForEntity("http://localhost:8001/api/clients/" + clientId,
                ClientDto.class);

        ClientDto client = clientDto.getBody();
        if (client == null) {
            throw new AccountException("Cliente no existe");
        }
        return lstTrans.stream().map(det -> {
            det.setClient(client.getName());

            return det;
        }).collect(Collectors.toList());
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        Transaction trans = transactionRepository.findTopByAccountIdOrderByDateDesc(accountId)
                .orElseThrow(() -> new AccountException(CodeTransactionMessage.TRANSACCION_ACCOUNDID_NOT_FOUND));

        return transactionMapper.toDto(trans);

    }

}
