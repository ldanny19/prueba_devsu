package com.devsu.hackerearth.backend.account.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;


@Mapper(componentModel = "spring")
public interface TransactionMapper2 {

    Transaction toEntity(TransactionDto dto);

    TransactionDto toDto(Transaction entity);

    List<Transaction> toEntityList(List<TransactionDto> dtoList);
    List<TransactionDto> toDtoList(List<Transaction> entityList);

}
