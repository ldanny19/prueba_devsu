package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.constants.CodeAccountMessage;
import com.devsu.hackerearth.backend.account.constants.TypeTransaction;
import com.devsu.hackerearth.backend.account.exception.AccountException;
import com.devsu.hackerearth.backend.account.mapper.AccountMapper;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final AccountMapper accountMapper;
    private final TransactionRepository transactionRepository;

    public AccountServiceImpl(AccountRepository accountRepository, AccountMapper accountMapper,
            TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.accountMapper = accountMapper;
        this.transactionRepository = transactionRepository;
    }

    @Override
    public List<AccountDto> getAll() {
        List<Account> listAccouts = accountRepository.findAll();
        if (listAccouts.isEmpty()) {
            throw new AccountException(CodeAccountMessage.ACCOUNT_DATA_NOT_FOUND);
        }
        return accountMapper.toDtoList(listAccouts);
    }

    @Override
    public AccountDto getById(Long id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new AccountException(CodeAccountMessage.ACCOUNT_NOT_FOUND));
        return accountMapper.toDto(account);
    }

    @Override
    @Transactional
    public AccountDto create(AccountDto accountDto) {
        Account account = accountMapper.toEntity(accountDto);
        Account accountSaved = accountRepository.save(account);
        Transaction trans = new Transaction();
        trans.setAccountId(accountSaved.getId());
        trans.setAmount(accountSaved.getInitialAmount());
        trans.setBalance(accountSaved.getInitialAmount());
        trans.setType(TypeTransaction.CREDITO.name());
        trans.setDate(new Date());
        transactionRepository.save(trans);
        return accountMapper.toDto(accountSaved);
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        accountRepository.findById(accountDto.getId())
                .orElseThrow(() -> new AccountException(CodeAccountMessage.ACCOUNT_NOT_FOUND));
        Account account = accountMapper.toEntity(accountDto);
        Account accountUpdated = accountRepository.save(account);
        return accountMapper.toDto(accountUpdated);
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new AccountException(CodeAccountMessage.ACCOUNT_NOT_FOUND));
        account.setActive(partialAccountDto.isActive());
        Account accountUpdated = accountRepository.save(account);
        return accountMapper.toDto(accountUpdated);
    }

    @Override
    public void deleteById(Long id) {
        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new AccountException(CodeAccountMessage.ACCOUNT_NOT_FOUND));
        accountRepository.delete(account);
    }

}
