package com.devsu.hackerearth.backend.account.model.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.devsu.hackerearth.backend.account.constants.CodeAccountMessage;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AccountDto {

	private Long id;
	@NotBlank(message = CodeAccountMessage.ACCOUNT_NUMBER_OBLIGATORY)
	private String number;
	@NotBlank(message = CodeAccountMessage.ACCOUNT_TYPE_OBLIGATORY)
	private String type;
	@NotNull(message = CodeAccountMessage.ACCOUNT_INIT_AMOUNT_OBLIGATORY)
	@Positive(message = CodeAccountMessage.ACCOUNT_INIT_AMOUNT_POSITIBE)
	private double initialAmount;

	private boolean isActive;
	@NotNull(message = CodeAccountMessage.ACCOUNT_CLIENTID_OBLIGATORY)
	private Long clientId;
}
