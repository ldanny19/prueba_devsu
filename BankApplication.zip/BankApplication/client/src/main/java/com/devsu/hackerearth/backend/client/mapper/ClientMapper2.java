package com.devsu.hackerearth.backend.client.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;

@Mapper(componentModel = "spring")
public interface ClientMapper2 {

    Client toEntity(ClientDto dto);

    ClientDto toDto(Client client);

    List<Client> toEntityList(List<ClientDto> dtoList);
    List<ClientDto> toDtoList(List<Client> clientList);

}
