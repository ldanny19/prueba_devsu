package com.devsu.hackerearth.backend.client.constants;

public final class CodeMessage {

    public static final String CLIENTS_DATA_NOT_FOUND = "Datos de CLientes no encontrados";
    public static final String CLIENT_NOT_FOUND = "Cliente no existe";
    public static final String CLIENT_DNI_OBLIGATORY = "El DNI del Cliente es obligatorio";
    public static final String CLIENT_NAME_OBLIGATORY = "El Nombre del Cliente es obligatorio";
    public static final String CLIENT_PASS_OBLIGATORY = "El PAssword del Cliente es obligatorio";
    public static final String CLIENT_GENDER_OBLIGATORY = "El genero del Cliente es obligatorio";
    public static final String CLIENT_ADDRESS_OBLIGATORY = "La Direccion del Cliente es obligatorio";
    public static final String CLIENT_AGE_POSITIVE = "La edad del Cliente debe ser mayor que 0";
    public static final String CLIENT_PHONE_OBLIGATORY = "El teelefono del Cliente es obligatorio";
    public static final String CLIENT_STATUS_OBLIGATORY = "El estado del Cliente es obligatorio";

}