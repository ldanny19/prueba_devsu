package com.devsu.hackerearth.backend.client.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PutMapping;

import com.devsu.hackerearth.backend.client.constants.CodeMessage;
import com.devsu.hackerearth.backend.client.exception.ClientException;
import com.devsu.hackerearth.backend.client.mapper.ClientMapper;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;
	private final ClientMapper clientMapper;

	public ClientServiceImpl(ClientRepository clientRepository, ClientMapper clientMapper) {
		this.clientRepository = clientRepository;
		this.clientMapper = clientMapper;
	}

	@Override
	public List<ClientDto> getAll() {
		List<Client> lstClients = clientRepository.findAll();
		if (lstClients.isEmpty()) {
			throw new ClientException(CodeMessage.CLIENTS_DATA_NOT_FOUND);
		}

		return clientMapper.toDtoList(lstClients);
	}

	@Override
	public ClientDto getById(Long id) {

		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new ClientException(CodeMessage.CLIENT_NOT_FOUND));
		return clientMapper.toDto(client);
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		Client client = clientMapper.toEntity(clientDto);
		Client clientSaved = clientRepository.save(client);
		return clientMapper.toDto(clientSaved);
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client
		clientRepository.findById(clientDto.getId())
				.orElseThrow(() -> new ClientException(CodeMessage.CLIENT_NOT_FOUND));
		Client client = clientMapper.toEntity(clientDto);
		Client clientUpdate = clientRepository.save(client);
		return clientMapper.toDto(clientUpdate);
	}

	@Override
	@PutMapping
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update account
		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new ClientException(CodeMessage.CLIENT_NOT_FOUND));
		client.setActive(partialClientDto.isActive());
		Client clientUpdate = clientRepository.save(client);
		return clientMapper.toDto(clientUpdate);
	}

	@Override
	public void deleteById(Long id) {
		// Delete client
		Client client = clientRepository.findById(id)
				.orElseThrow(() -> new ClientException(CodeMessage.CLIENT_NOT_FOUND));
		clientRepository.delete(client);
	}
}
