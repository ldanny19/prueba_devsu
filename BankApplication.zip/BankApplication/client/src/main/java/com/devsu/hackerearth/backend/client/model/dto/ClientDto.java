package com.devsu.hackerearth.backend.client.model.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;

import com.devsu.hackerearth.backend.client.constants.CodeMessage;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ClientDto {

	private Long id;
	@NotBlank(message = CodeMessage.CLIENT_DNI_OBLIGATORY)
	private String dni;
	@NotBlank(message = CodeMessage.CLIENT_NAME_OBLIGATORY)
	private String name;
	@NotBlank(message = CodeMessage.CLIENT_PASS_OBLIGATORY)
	private String password;
	@NotBlank(message = CodeMessage.CLIENT_GENDER_OBLIGATORY)
	private String gender;
	@Positive(message = CodeMessage.CLIENT_AGE_POSITIVE)
	private int age;
	@NotBlank(message = CodeMessage.CLIENT_ADDRESS_OBLIGATORY)
	private String address;
	@NotBlank(message = CodeMessage.CLIENT_PHONE_OBLIGATORY)
	private String phone;
	private boolean isActive;
}
