package com.devsu.hackerearth.backend.client.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;

@Component
public class ClientMapper {

    public Client toEntity(ClientDto dto) {
        if (dto == null) {
            return null;
        }
        Client obj = new Client();
        obj.setId(dto.getId());
        obj.setDni(dto.getDni());
        obj.setName(dto.getName());
        obj.setAddress(dto.getAddress());
        obj.setAge(dto.getAge());
        obj.setGender(dto.getGender());
        obj.setPhone(dto.getPhone());
        obj.setPassword(dto.getPassword());
        obj.setActive(dto.isActive());
        return obj;
    }

    public ClientDto toDto(Client entity) {

        if (entity == null) {
            return null;
        }
        ClientDto obj = new ClientDto(entity.getId(), entity.getDni(), entity.getName(), entity.getPassword(),
                entity.getGender(), entity.getAge(), entity.getAddress(), entity.getPhone(), entity.isActive());
        return obj;
    }

    public List<Client> toEntityList(List<ClientDto> dtoList) {
        if (dtoList == null) {
            return null;
        }
        return dtoList.stream().map(this::toEntity).collect(Collectors.toList());
    }

    public List<ClientDto> toDtoList(List<Client> entityList) {
        if (entityList == null) {
            return null;
        }
        return entityList.stream().map(this::toDto).collect(Collectors.toList());
    }

}
