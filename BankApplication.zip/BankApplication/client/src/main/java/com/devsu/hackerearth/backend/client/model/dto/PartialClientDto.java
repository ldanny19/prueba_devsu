package com.devsu.hackerearth.backend.client.model.dto;

import javax.validation.constraints.NotNull;

import com.devsu.hackerearth.backend.client.constants.CodeMessage;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PartialClientDto {

    @NotNull(message = CodeMessage.CLIENT_STATUS_OBLIGATORY)
    private boolean isActive;
}
